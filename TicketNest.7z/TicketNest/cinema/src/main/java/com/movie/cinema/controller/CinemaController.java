package com.movie.cinema.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.movie.cinema.entity.Cinema;
import com.movie.cinema.service.CinemaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cinemas")
public class CinemaController {
    private static final Logger logger = LoggerFactory.getLogger(CinemaController.class);

    @Autowired
    private CinemaService cinemaService;

    @PostMapping
    public ResponseEntity<Cinema> addCinema(@RequestBody Cinema cinema) {
        logger.info("Received request to add cinema: {}", cinema.getName());

        Cinema savedCinema = cinemaService.addCinema(cinema);
        logger.info("Cinema added successfully: {}", savedCinema.getName());

        return ResponseEntity.ok(savedCinema);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Cinema> updateCinema(@PathVariable Integer id, @RequestBody Cinema cinema) {
        logger.info("Received request to update cinema ID: {}", id);
        return ResponseEntity.ok(cinemaService.updateCinema(id, cinema));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCinema(@PathVariable Integer id) {
        logger.warn("Deleting cinema ID: {}", id);
        cinemaService.deleteCinema(id);
        return ResponseEntity.ok("Cinema deleted successfully.");
    }

    @GetMapping
    public ResponseEntity<List<Cinema>> getAllCinemas() {
        logger.debug("Fetching all cinemas...");
        return ResponseEntity.ok(cinemaService.getAllCinemas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<List<Cinema>> getCinemaById(@PathVariable Integer id) {
        logger.debug("Fetching cinema with ID: {}", id);
        
        List<Cinema> cinemas = cinemaService.getCinemasByMerchantId(id);
        
        if (cinemas == null || cinemas.isEmpty()) {
            throw new RuntimeException("Cinema with ID " + id + " not found.");
        }
        
        return ResponseEntity.ok(cinemas);
    }

    @GetMapping("/by-movie")
    public ResponseEntity<List<Cinema>> getCinemasByMovieId(@RequestParam Integer movieId) {
        logger.debug("Fetching cinemas for Movie ID: {}", movieId);
        List<Cinema> cinemas = cinemaService.getCinemasByMovieId(movieId);
        return ResponseEntity.ok(cinemas);
    }
}