package com.movie.cinema.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.movie.cinema.entity.Cinema;
import com.movie.cinema.repository.CinemaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CinemaService {
    private static final Logger logger = LoggerFactory.getLogger(CinemaService.class);

    @Autowired
    private CinemaRepository cinemaRepository;

    public Cinema addCinema(Cinema cinema) {
        logger.info("Adding cinema: {}", cinema.getName());

        cinema.setCreatedAt(LocalDateTime.now());
        Cinema savedCinema = cinemaRepository.save(cinema);

        logger.info("Cinema saved successfully: {}", savedCinema.getName());
        return savedCinema;
    }

    public Cinema updateCinema(Integer id, Cinema cinemaDetails) {
        logger.info("Updating cinema ID: {}", id);

        Cinema cinema = cinemaRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Cinema not found: ID {}", id);
                    return new RuntimeException("Cinema not found with id " + id);
                });

        cinema.setName(cinemaDetails.getName());
        cinema.setDescription(cinemaDetails.getDescription());
        cinema.setLocation(cinemaDetails.getLocation());

        Cinema updatedCinema = cinemaRepository.save(cinema);
        logger.info("Cinema updated successfully: {}", updatedCinema.getName());

        return updatedCinema;
    }

    public void deleteCinema(Integer id) {
        logger.warn("Deleting cinema ID: {}", id);

        Cinema cinema = cinemaRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Cinema not found for deletion: ID {}", id);
                    return new RuntimeException("Cinema not found with id " + id);
                });

        cinemaRepository.delete(cinema);
        logger.info("Cinema deleted successfully: ID {}", id);
    }

    public List<Cinema> getAllCinemas() {
        logger.debug("Retrieving all cinemas from database...");
        return cinemaRepository.findAll();
    }
    
    public Cinema getCinemaById(Integer id) {
    	logger.info("Retrieving cinema by ID: {}", id);
        return cinemaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cinema not found with id " + id)); // Find by ID
    }
    
    public List<Cinema> getCinemasByMerchantId(Integer merchantId) {
    	logger.info("Retrieving all cinemas by Merchant ID: {}", merchantId);
        List<Cinema> cinemas = cinemaRepository.findByMerchantId(merchantId);
        if (cinemas.isEmpty()) {
            throw new RuntimeException("No cinemas found for merchant ID " + merchantId);
        }
        return cinemas;
    }
    
    public List<Cinema> getCinemasByMovieId(Integer movieId) {
    	logger.info("Retrieving all cinemas by Movie Id: {}", movieId);
        return cinemaRepository.findCinemasByMovieId(movieId);
    }
}