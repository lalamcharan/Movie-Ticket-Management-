package com.movie.cinema.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.movie.cinema.entity.Cinema;
import com.movie.cinema.service.CinemaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;

import java.util.List;

@ExtendWith(MockitoExtension.class)
class CinemaControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CinemaService cinemaService;

    @InjectMocks
    private CinemaController cinemaController;

    private Cinema cinema;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(cinemaController).build();
        cinema = new Cinema();
        cinema.setId(1);
        cinema.setName("Elite Cinema");
        cinema.setLocation("Downtown");
    }

    @Test
    void testAddCinema() throws Exception {
        when(cinemaService.addCinema(any(Cinema.class))).thenReturn(cinema);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/cinemas")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(cinema)))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void testUpdateCinema() throws Exception {
        when(cinemaService.updateCinema(anyInt(), any(Cinema.class))).thenReturn(cinema);

        mockMvc.perform(MockMvcRequestBuilders.put("/api/cinemas/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(cinema)))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void testDeleteCinema() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/cinemas/1"))
                .andExpect(MockMvcResultMatchers.status().isOk());
        verify(cinemaService, times(1)).deleteCinema(1);
    }

    @Test
    void testGetAllCinemas() throws Exception {
        when(cinemaService.getAllCinemas()).thenReturn(List.of(cinema));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/cinemas"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void testGetCinemaById() throws Exception {
        when(cinemaService.getCinemasByMerchantId(1)).thenReturn(List.of(cinema));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/cinemas/1"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}