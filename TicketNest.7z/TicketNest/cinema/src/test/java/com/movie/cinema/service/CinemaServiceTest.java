package com.movie.cinema.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.movie.cinema.entity.Cinema;
import com.movie.cinema.repository.CinemaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class CinemaServiceTest {

    @Mock
    private CinemaRepository cinemaRepository;

    @InjectMocks
    private CinemaService cinemaService;

    private Cinema cinema;

    @BeforeEach
    void setUp() {
        cinema = new Cinema();
        cinema.setId(1);
        cinema.setName("Elite Cinema");
        cinema.setLocation("Downtown");
        cinema.setCreatedAt(LocalDateTime.now());
    }

    @Test
    void testAddCinema() {
        when(cinemaRepository.save(any(Cinema.class))).thenReturn(cinema);

        Cinema savedCinema = cinemaService.addCinema(cinema);

        assertNotNull(savedCinema);
        assertEquals("Elite Cinema", savedCinema.getName());
    }

    @Test
    void testUpdateCinema() {
        Cinema updatedCinema = new Cinema();
        updatedCinema.setName("Updated Cinema");

        when(cinemaRepository.findById(1)).thenReturn(Optional.of(cinema));
        when(cinemaRepository.save(any(Cinema.class))).thenReturn(updatedCinema);

        Cinema result = cinemaService.updateCinema(1, updatedCinema);

        assertNotNull(result);
        assertEquals("Updated Cinema", result.getName());
    }

    @Test
    void testDeleteCinema() {
        when(cinemaRepository.findById(1)).thenReturn(Optional.of(cinema));

        assertDoesNotThrow(() -> cinemaService.deleteCinema(1));
        verify(cinemaRepository, times(1)).delete(cinema);
    }

    @Test
    void testGetCinemaById() {
        when(cinemaRepository.findById(1)).thenReturn(Optional.of(cinema));

        Cinema result = cinemaService.getCinemaById(1);

        assertNotNull(result);
        assertEquals("Elite Cinema", result.getName());
    }
}