package com.movie.loginservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.movie.loginservice.dto.LoginRequest;
import com.movie.loginservice.dto.LoginResponse;
import com.movie.loginservice.entity.User;
import com.movie.loginservice.service.LoginService;
import com.movie.loginservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/login")
public class LoginController {
    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    private UserService service;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    private LoginService loginService;

    @PostMapping
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
        logger.info("Login attempt for username: {}", loginRequest.getUsername());

        LoginResponse loginResponse = loginService.login(loginRequest);

        logger.info("Login successful for user: {}", loginRequest.getUsername());
        return ResponseEntity.ok(loginResponse);
    }

    @PostMapping("register")
    public User register(@RequestBody User user) {
        logger.info("New registration request for username: {}", user.getUsername());

        User savedUser = service.saveUser(user);

        logger.info("User registered successfully: {}", user.getUsername());
        return savedUser;
    }


    
//    @PostMapping
//	public String login(@RequestBody User user){
//    	System.out.println("Inside the login");
//		Authentication authentication = authenticationManager
//				.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
//
//		if(authentication.isAuthenticated())
//			return jwtService.generateToken(user.getUsername(), user.getRole());
//		else
//			return "Login Failed";
//
//	}

//    @PostMapping
//    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest request) {
//        LoginResponse loginResponse = loginService.login(request.getEmail(), request.getPassword());
//
//        // Wrap the response inside a "data" field to maintain consistency
//        return ResponseEntity
//                .status(loginResponse.getStatusCode())
//                .body(Collections.singletonMap("data", loginResponse));
//    }
}
