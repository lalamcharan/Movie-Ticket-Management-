package com.movie.loginservice.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtService {

	private final String jwtsecret = "your_secret_key_here_make_it_long_and_secure_for_better_security"; // 256-bit key
	 private final long jwtExpiration = 86400000; // 1 day in milliseconds

	 public String generateToken(String username, String role) {
		 
		 System.out.println("Role: " + role);
		    // Create claims map
		    Map<String, Object> claims = new HashMap<>();
		    claims.put("role", role);

		    // Generate JWT Token using correct key method
		    Key key = Keys.hmacShaKeyFor(jwtsecret.getBytes(StandardCharsets.UTF_8));

		    return Jwts.builder()
		            .setClaims(claims) // Set claims properly
		            .setSubject(username)
		            .setIssuedAt(new Date())
		            .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration)) // 1 day
		            .signWith(key, SignatureAlgorithm.HS256)
		            .compact();
		}
}