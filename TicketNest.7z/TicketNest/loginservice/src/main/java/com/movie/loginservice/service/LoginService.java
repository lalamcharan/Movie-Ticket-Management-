package com.movie.loginservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.movie.loginservice.dto.LoginRequest;
import com.movie.loginservice.dto.LoginResponse;
import com.movie.loginservice.dto.UserData;
import com.movie.loginservice.entity.User;
import com.movie.loginservice.exceptions.UserAlreadyExistsException;
import com.movie.loginservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class LoginService {
    private static final Logger logger = LoggerFactory.getLogger(LoginService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtService jwtUtil;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    public LoginResponse login(LoginRequest request) {
        logger.info("Processing login for user: {}", request.getUsername());

        User user = userRepository.findByUsername(request.getUsername());

        if (user == null) {
            logger.warn("User not found: {}", request.getUsername());
            throw new UserAlreadyExistsException("User not found.");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            logger.warn("Invalid password attempt for user: {}", request.getUsername());
            throw new UserAlreadyExistsException("Invalid password. Try again.");
        }

        String token = jwtUtil.generateToken(user.getUsername(), user.getRole());
        logger.info("Token generated successfully for user: {}", request.getUsername());

        return new LoginResponse(token, new UserData(user.getId(), user.getEmail(), user.getName(), user.getPhone(), user.getRole()), "Login successful", 200);
    }
}