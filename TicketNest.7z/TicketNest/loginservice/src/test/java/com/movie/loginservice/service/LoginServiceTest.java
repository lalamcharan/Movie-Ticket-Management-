package com.movie.loginservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.movie.loginservice.dto.LoginRequest;
import com.movie.loginservice.dto.LoginResponse;
import com.movie.loginservice.entity.User;
import com.movie.loginservice.repository.UserRepository;
import com.movie.loginservice.service.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

@ExtendWith(MockitoExtension.class)
class LoginServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private JwtService jwtService;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private LoginService loginService;

    private User user;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setUsername("testUser");
        user.setPassword("encodedPassword");
        user.setRole("USER");
    }

    @Test
    void testLoginSuccess() {
        LoginRequest request = new LoginRequest("testUser", "plainPassword");
        when(userRepository.findByUsername("testUser")).thenReturn(user);
        when(passwordEncoder.matches("plainPassword", user.getPassword())).thenReturn(true);
        when(jwtService.generateToken(user.getUsername(), user.getRole())).thenReturn("mockJwtToken");

        LoginResponse response = loginService.login(request);

        assertNotNull(response);
        assertEquals("mockJwtToken", response.getToken());
        assertEquals("Login successful", response.getMessage());
    }

    @Test
    void testLoginFailure_InvalidPassword() {
        LoginRequest request = new LoginRequest("testUser", "wrongPassword");
        when(userRepository.findByUsername("testUser")).thenReturn(user);
        when(passwordEncoder.matches("wrongPassword", user.getPassword())).thenReturn(false);

        assertThrows(Exception.class, () -> loginService.login(request));
    }
}