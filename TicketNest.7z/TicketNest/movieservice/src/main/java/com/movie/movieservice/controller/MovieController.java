package com.movie.movieservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.movie.movieservice.entity.Movie;
import com.movie.movieservice.service.JwtService;
import com.movie.movieservice.service.MovieService;
import org.apache.hc.core5.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/movies")
public class MovieController {
    private static final Logger logger = LoggerFactory.getLogger(MovieController.class);

    @Autowired
    private MovieService movieService;

    @Autowired
    private JwtService jwtTokenUtil;

    @PostMapping
    public ResponseEntity<Movie> addMovie(@RequestBody Movie movie, @RequestHeader("Authorization") String authHeader) {
        logger.info("Received request to add a movie: {}", movie.getTitle());

        // Extract JWT token
        String token = authHeader.substring(7);
        String role = jwtTokenUtil.extractRole(token);

        if (!"MERCHANT".equals(role)) {
            logger.warn("Unauthorized attempt to add a movie");
            return ResponseEntity.status(HttpStatus.SC_UNAUTHORIZED).build();
        }

        Movie savedMovie = movieService.addMovie(movie);
        logger.info("Movie added successfully: {}", savedMovie.getTitle());

        return ResponseEntity.ok(savedMovie);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Movie> updateMovie(@PathVariable Integer id, @RequestBody Movie movie) {
        logger.info("Received request to update movie ID: {}", id);
        return ResponseEntity.ok(movieService.updateMovie(id, movie));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteMovie(@PathVariable Integer id) {
        logger.warn("Deleting movie ID: {}", id);
        movieService.deleteMovie(id);
        return ResponseEntity.ok("Movie deleted successfully.");
    }

    @GetMapping
    public ResponseEntity<List<Movie>> getAllMovies() {
        logger.debug("Fetching all movies...");
        return ResponseEntity.ok(movieService.getAllMovies());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Movie> getMovieById(@PathVariable Integer id) {
        logger.debug("Fetching movie with ID: {}", id);
        return ResponseEntity.ok(movieService.getMovieById(id));
    }
}