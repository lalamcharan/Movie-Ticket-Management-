package com.movie.movieservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.movie.movieservice.entity.Movie;
import com.movie.movieservice.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MovieService {
    private static final Logger logger = LoggerFactory.getLogger(MovieService.class);

    @Autowired
    private MovieRepository movieRepository;

    public Movie addMovie(Movie movie) {
        logger.info("Adding new movie: {}", movie.getTitle());
        movie.setCreatedAt(LocalDateTime.now());
        Movie savedMovie = movieRepository.save(movie);
        logger.info("Movie saved successfully: {}", savedMovie.getTitle());
        return savedMovie;
    }

    public Movie updateMovie(Integer id, Movie movieDetails) {
        logger.info("Updating movie ID: {}", id);
        Movie movie = movieRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Movie not found: ID {}", id);
                    return new RuntimeException("Movie not found with id " + id);
                });

        movie.setTitle(movieDetails.getTitle());
        movie.setDescription(movieDetails.getDescription());
        movie.setGenre(movieDetails.getGenre());
        movie.setReleaseDate(movieDetails.getReleaseDate());
        movie.setLanguage(movieDetails.getLanguage());
        movie.setDurationMinutes(movieDetails.getDurationMinutes());

        Movie updatedMovie = movieRepository.save(movie);
        logger.info("Movie updated successfully: {}", updatedMovie.getTitle());
        return updatedMovie;
    }

    public void deleteMovie(Integer id) {
        logger.warn("Deleting movie with ID: {}", id);
        Movie movie = movieRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Movie not found for deletion: ID {}", id);
                    return new RuntimeException("Movie not found with id " + id);
                });

        movieRepository.delete(movie);
        logger.info("Movie deleted successfully: {}", movie.getTitle());
    }

    public List<Movie> getAllMovies() {
        logger.debug("Retrieving all movies from database...");
        return movieRepository.findAll();
    }

    public Movie getMovieById(Integer id) {
        logger.debug("Retrieving movie by ID: {}", id);
        return movieRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Movie not found: ID {}", id);
                    return new RuntimeException("Movie not found with id " + id);
                });
    }
}