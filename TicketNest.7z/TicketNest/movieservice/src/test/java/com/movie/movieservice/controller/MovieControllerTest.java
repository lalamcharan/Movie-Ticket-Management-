package com.movie.movieservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.movie.movieservice.entity.Movie;
import com.movie.movieservice.service.JwtService;
import com.movie.movieservice.service.MovieService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;

import java.util.List;

@ExtendWith(MockitoExtension.class)
class MovieControllerTest {

    private MockMvc mockMvc;

    @Mock
    private MovieService movieService;

    @Mock
    private JwtService jwtTokenUtil;

    @InjectMocks
    private MovieController movieController;

    private Movie movie;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(movieController).build();
        movie = new Movie();
        movie.setId(1);
        movie.setTitle("Inception");
    }

    @Test
    void testAddMovie_Success() throws Exception {
        when(jwtTokenUtil.extractRole(anyString())).thenReturn("MERCHANT");
        when(movieService.addMovie(any(Movie.class))).thenReturn(movie);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/movies")
                .header("Authorization", "Bearer mockJwtToken")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(movie)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title").value("Inception"));
    }

    @Test
    void testAddMovie_Unauthorized() throws Exception {
        when(jwtTokenUtil.extractRole(anyString())).thenReturn("USER");

        mockMvc.perform(MockMvcRequestBuilders.post("/api/movies")
                .header("Authorization", "Bearer mockJwtToken")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(movie)))
                .andExpect(MockMvcResultMatchers.status().isUnauthorized());
    }

    @Test
    void testUpdateMovie() throws Exception {
        when(movieService.updateMovie(anyInt(), any(Movie.class))).thenReturn(movie);

        mockMvc.perform(MockMvcRequestBuilders.put("/api/movies/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(movie)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title").value("Inception"));
    }

    @Test
    void testDeleteMovie() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/movies/1"))
                .andExpect(MockMvcResultMatchers.status().isOk());
        verify(movieService, times(1)).deleteMovie(1);
    }

    @Test
    void testGetAllMovies() throws Exception {
        when(movieService.getAllMovies()).thenReturn(List.of(movie));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/movies"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].title").value("Inception"));
    }

    @Test
    void testGetMovieById() throws Exception {
        when(movieService.getMovieById(1)).thenReturn(movie);

        mockMvc.perform(MockMvcRequestBuilders.get("/api/movies/1"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title").value("Inception"));
    }
}