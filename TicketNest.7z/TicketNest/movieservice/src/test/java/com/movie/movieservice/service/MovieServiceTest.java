package com.movie.movieservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.movie.movieservice.entity.Movie;
import com.movie.movieservice.repository.MovieRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class MovieServiceTest {

    @Mock
    private MovieRepository movieRepository;

    @InjectMocks
    private MovieService movieService;

    private Movie movie;

    @BeforeEach
    void setUp() {
        movie = new Movie();
        movie.setId(1);
        movie.setTitle("Inception");
        movie.setCreatedAt(LocalDateTime.now());
    }

    @Test
    void testAddMovie() {
        when(movieRepository.save(any(Movie.class))).thenReturn(movie);

        Movie savedMovie = movieService.addMovie(movie);

        assertNotNull(savedMovie);
        assertEquals("Inception", savedMovie.getTitle());
    }

    @Test
    void testUpdateMovie() {
        Movie updatedMovie = new Movie();
        updatedMovie.setTitle("Updated Title");

        when(movieRepository.findById(1)).thenReturn(Optional.of(movie));
        when(movieRepository.save(any(Movie.class))).thenReturn(updatedMovie);

        Movie result = movieService.updateMovie(1, updatedMovie);

        assertNotNull(result);
        assertEquals("Updated Title", result.getTitle());
    }

    @Test
    void testDeleteMovie() {
        when(movieRepository.findById(1)).thenReturn(Optional.of(movie));

        assertDoesNotThrow(() -> movieService.deleteMovie(1));
        verify(movieRepository, times(1)).delete(movie);
    }

    @Test
    void testGetMovieById() {
        when(movieRepository.findById(1)).thenReturn(Optional.of(movie));

        Movie result = movieService.getMovieById(1);

        assertNotNull(result);
        assertEquals("Inception", result.getTitle());
    }
}