package com.movie.otpverificationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtpverificationserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtpverificationserviceApplication.class, args);
	}

}
