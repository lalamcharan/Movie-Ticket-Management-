package com.movie.otpverificationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtpverificationserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
