package com.movie.otpverificationservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.movie.otpverificationservice.entity.OTP;
import com.movie.otpverificationservice.service.OtpVerificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;

import java.util.List;

@ExtendWith(MockitoExtension.class)
class OtpVerificationControllerTest {

    private MockMvc mockMvc;

    @Mock
    private OtpVerificationService otpVerificationService;

    @InjectMocks
    private OtpVerificationController otpVerificationController;

    private OTP otp;


    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(otpVerificationController).build();
        otp = new OTP();
        otp.setId(1);
        otp.setOtpCode("123456");
        otp.setIsVerified(false);
    }

    @Test
    void testAddOtp() throws Exception {
        when(otpVerificationService.addOtp(any(OTP.class))).thenReturn(otp);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/otp")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(otp)))
                .andExpect(MockMvcResultMatchers.status().isOk());
 }

    @Test
    void testUpdateOtp() throws Exception {
        when(otpVerificationService.updateOtp(anyInt(), any(OTP.class))).thenReturn(otp);

        mockMvc.perform(MockMvcRequestBuilders.put("/api/otp/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(otp)))
                .andExpect(MockMvcResultMatchers.status().isOk());
        }

    @Test
    void testDeleteOtp() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/otp/1"))
                .andExpect(MockMvcResultMatchers.status().isOk());
        verify(otpVerificationService, times(1)).deleteOtp(1);
    }

    @Test
    void testGetAllOtps() throws Exception {
        when(otpVerificationService.getAllOtps()).thenReturn(List.of(otp));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/otp"))
                .andExpect(MockMvcResultMatchers.status().isOk());
 }

    @Test
    void testGetOtpById() throws Exception {
        when(otpVerificationService.getOtpById(1)).thenReturn(otp);

        mockMvc.perform(MockMvcRequestBuilders.get("/api/otp/1"))
                .andExpect(MockMvcResultMatchers.status().isOk());
 }
}