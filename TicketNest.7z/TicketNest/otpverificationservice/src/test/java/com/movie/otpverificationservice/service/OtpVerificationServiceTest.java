package com.movie.otpverificationservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.movie.otpverificationservice.entity.OTP;
import com.movie.otpverificationservice.repository.OtpVerificationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class OtpVerificationServiceTest {

    @Mock
    private OtpVerificationRepository otpVerificationRepository;

    @InjectMocks
    private OtpVerificationService otpVerificationService;

    private OTP otp;

    @BeforeEach
    void setUp() {
        otp = new OTP();
        otp.setId(1);
        otp.setOtpCode("123456");
        otp.setCreatedAt(LocalDateTime.now());
        otp.setExpiresAt(LocalDateTime.now().plusDays(7));
        otp.setIsVerified(false);
    }

    @Test
    void testAddOtp() {
        when(otpVerificationRepository.save(any(OTP.class))).thenReturn(otp);

        OTP savedOtp = otpVerificationService.addOtp(otp);

        assertNotNull(savedOtp);
        assertEquals("123456", savedOtp.getOtpCode());
        assertFalse(savedOtp.getIsVerified());
    }

    @Test
    void testUpdateOtp() {
        OTP updatedOtp = new OTP();
        updatedOtp.setOtpCode("654321");

        when(otpVerificationRepository.findById(1)).thenReturn(Optional.of(otp));
        when(otpVerificationRepository.save(any(OTP.class))).thenReturn(updatedOtp);

        OTP result = otpVerificationService.updateOtp(1, updatedOtp);

        assertNotNull(result);
        assertEquals("654321", result.getOtpCode());
    }

    @Test
    void testDeleteOtp() {
        when(otpVerificationRepository.findById(1)).thenReturn(Optional.of(otp));

        assertDoesNotThrow(() -> otpVerificationService.deleteOtp(1));
        verify(otpVerificationRepository, times(1)).delete(otp);
    }

    @Test
    void testGetOtpById() {
        when(otpVerificationRepository.findById(1)).thenReturn(Optional.of(otp));

        OTP result = otpVerificationService.getOtpById(1);

        assertNotNull(result);
        assertEquals("123456", result.getOtpCode());
    }
}