package com.movie.registration.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.movie.registration.entity.User;
import com.movie.registration.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/register")
public class RegistrationController {
    private static final Logger logger = LoggerFactory.getLogger(RegistrationController.class);

    @Autowired
    private RegistrationService registrationService;

    @PostMapping
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        logger.info("Received registration request for username: {}", user.getUsername());

        try {
            User registeredUser = registrationService.registerUser(user);
            logger.info("User registered successfully: {}", user.getUsername());
            return ResponseEntity.ok(registeredUser);
        } catch (RuntimeException e) {
            logger.error("Registration failed for user {}: {}", user.getUsername(), e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
}