package com.movie.registration.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.movie.registration.entity.User;
import com.movie.registration.exceptions.UserAlreadyExistsException;
import com.movie.registration.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class RegistrationService {
    private static final Logger logger = LoggerFactory.getLogger(RegistrationService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User registerUser(User user) {
        logger.info("Processing registration for user: {}", user.getUsername());

        if (userRepository.existsByEmail(user.getEmail())) {
            logger.warn("Registration failed - Email already registered: {}", user.getEmail());
            throw new UserAlreadyExistsException("Email already registered !!");
        }

        if (userRepository.existsByUsername(user.getUsername())) {
            logger.warn("Registration failed - Username already registered: {}", user.getUsername());
            throw new UserAlreadyExistsException("Username already registered!!");
        }

        user.setCreatedAt(LocalDateTime.now());
        user.setPassword(passwordEncoder.encode(user.getPassword())); // Hash the password

        User savedUser = userRepository.save(user);
        logger.info("User registered successfully: {}", user.getUsername());

        return savedUser;
    }

    private void generateAndSendOTP(User user) {
        String otpCode = String.valueOf(ThreadLocalRandom.current().nextInt(100000, 999999));
        logger.info("Generated OTP [{}] for user {}", otpCode, user.getUsername());
        // Logic to save OTP and send it via email/SMS
    }
}