package com.movie.showtimingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShowtimingserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShowtimingserviceApplication.class, args);
	}

}
