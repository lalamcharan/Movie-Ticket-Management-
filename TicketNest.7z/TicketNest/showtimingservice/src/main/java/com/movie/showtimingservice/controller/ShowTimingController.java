package com.movie.showtimingservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.movie.showtimingservice.dto.ShowTimingDTO;
import com.movie.showtimingservice.entity.ShowTiming;
import com.movie.showtimingservice.service.ShowTimingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/show-timings")
public class ShowTimingController {
    private static final Logger logger = LoggerFactory.getLogger(ShowTimingController.class);

    @Autowired
    private ShowTimingService showTimingService;

    @PostMapping
    public ResponseEntity<ShowTiming> addShowTiming(@RequestBody ShowTiming showTiming) {
        logger.info("Received request to add show timing for Movie ID: {}", showTiming.getMovieId());

        ShowTiming savedShowTiming = showTimingService.addShowTiming(showTiming);
        logger.info("Show timing added successfully: ID {}", savedShowTiming.getId());

        return ResponseEntity.ok(savedShowTiming);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ShowTiming> updateShowTiming(@PathVariable Integer id, @RequestBody ShowTiming showTiming) {
        logger.info("Received request to update show timing ID: {}", id);
        return ResponseEntity.ok(showTimingService.updateShowTiming(id, showTiming));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteShowTiming(@PathVariable Integer id) {
        logger.warn("Deleting show timing ID: {}", id);
        showTimingService.deleteShowTiming(id);
        return ResponseEntity.ok("Show timing deleted successfully.");
    }

    @GetMapping
    public ResponseEntity<List<ShowTiming>> getAllShowTimings() {
        logger.debug("Fetching all show timings...");
        return ResponseEntity.ok(showTimingService.getAllShowTimings());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ShowTiming> getShowTimingById(@PathVariable Integer id) {
        logger.debug("Fetching show timing ID: {}", id);
        return ResponseEntity.ok(showTimingService.getShowTimingById(id));
    }
    
    @GetMapping("/movie-cinema")
    public ResponseEntity<List<ShowTiming>> getByMovieIdAndCinemaId(
            @RequestParam(required = false) Integer movieId,
            @RequestParam(required = false) Integer cinemaId) {

        return ResponseEntity.ok(showTimingService.getShowTimingsByMovieIdAndCinemaId(movieId, cinemaId));
    }
    
    @GetMapping("/merchant/{merchantId}")
    public ResponseEntity<List<ShowTimingDTO>> getShowTimingsByMerchantId(@PathVariable Integer merchantId) {
        logger.debug("Fetching show timing ID: {}", merchantId);
        return ResponseEntity.ok(showTimingService.getShowTimingsByMerchantId(merchantId));
    }

    @GetMapping("/cinema/{cinemaId}")
    public ResponseEntity<List<ShowTiming>> getByCinemaId(@PathVariable Integer cinemaId) {
        logger.debug("Fetching show timings for Cinema ID: {}", cinemaId);
        return ResponseEntity.ok(showTimingService.getShowTimingsByCinemaId(cinemaId));
    }
}