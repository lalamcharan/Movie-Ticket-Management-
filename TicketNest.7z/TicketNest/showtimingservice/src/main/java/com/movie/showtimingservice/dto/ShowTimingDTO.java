package com.movie.showtimingservice.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class ShowTimingDTO {
    private String title;
    private String cinema;
    private LocalDate showDate;
    private LocalTime showTime;
    private Integer totalSeats;  // String to accept date
    private Double totalPrice;
    
	public ShowTimingDTO(String title, String cinema, LocalDate showDate, LocalTime showTime, Integer totalSeats,
			Double totalPrice) {
		super();
		this.title = title;
		this.cinema = cinema;
		this.showDate = showDate;
		this.showTime = showTime;
		this.totalSeats = totalSeats;
		this.totalPrice = totalPrice;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCinema() {
		return cinema;
	}
	public void setCinema(String cinema) {
		this.cinema = cinema;
	}
	public LocalDate getShowDate() {
		return showDate;
	}
	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}
	public LocalTime getShowTime() {
		return showTime;
	}
	public void setShowTime(LocalTime showTime) {
		this.showTime = showTime;
	}
	public Integer getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(Integer totalSeats) {
		this.totalSeats = totalSeats;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
    
	
    // Getters and Setters
}
