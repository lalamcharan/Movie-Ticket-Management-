package com.movie.showtimingservice.service;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.movie.showtimingservice.dto.ShowTimingDTO;
import com.movie.showtimingservice.entity.Cinema;
import com.movie.showtimingservice.entity.Movie;
import com.movie.showtimingservice.entity.ShowTiming;
import com.movie.showtimingservice.repository.CinemaRepository;
import com.movie.showtimingservice.repository.MovieRepository;
import com.movie.showtimingservice.repository.ShowTimingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ShowTimingService {
    private static final Logger logger = LoggerFactory.getLogger(ShowTimingService.class);

    @Autowired
    private ShowTimingRepository showTimingRepository;
    
    @Autowired
    private MovieRepository movieRepository;
    
    @Autowired
    private CinemaRepository cinemaRepository;

    public ShowTiming addShowTiming(ShowTiming showTiming) {
        logger.info("Adding show timing for movie ID: {}", showTiming.getMovieId());

        showTiming.setCreatedAt(LocalDateTime.now());
        showTiming.setAvailableSeats(showTiming.getTotalSeats());

        ShowTiming savedShowTiming = showTimingRepository.save(showTiming);
        logger.info("Show timing saved successfully: ID {}", savedShowTiming.getId());

        return savedShowTiming;
    }

    public ShowTiming updateShowTiming(Integer id, ShowTiming showTimingDetails) {
        logger.info("Updating show timing ID: {}", id);

        ShowTiming showTiming = showTimingRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Show timing not found: ID {}", id);
                    return new RuntimeException("Show timing not found with id " + id);
                });

        showTiming.setShowDate(showTimingDetails.getShowDate());
        showTiming.setShowTime(showTimingDetails.getShowTime());
        showTiming.setTicketPrice(showTimingDetails.getTicketPrice());
        showTiming.setTotalSeats(showTimingDetails.getTotalSeats());
        showTiming.setAvailableSeats(showTimingDetails.getTotalSeats());
        showTiming.setCinemaId(showTimingDetails.getCinemaId());
        showTiming.setMovieId(showTimingDetails.getMovieId());

        ShowTiming updatedShowTiming = showTimingRepository.save(showTiming);
        logger.info("Show timing updated successfully: ID {}", updatedShowTiming.getId());

        return updatedShowTiming;
    }

    public void deleteShowTiming(Integer id) {
        logger.warn("Deleting show timing ID: {}", id);

        ShowTiming showTiming = showTimingRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Show timing not found for deletion: ID {}", id);
                    return new RuntimeException("Show timing not found with id " + id);
                });

        showTimingRepository.delete(showTiming);
        logger.info("Show timing deleted successfully: ID {}", id);
    }

    public List<ShowTiming> getAllShowTimings() {
        logger.debug("Retrieving all show timings...");
        return showTimingRepository.findAll();
    }
    
    public ShowTiming getShowTimingById(Integer id) {
    	logger.debug("Retrieving Show Timing By Id: {}", id);
        return showTimingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Show timing not found with id " + id)); // Find by ID
    }
    
    public List<ShowTimingDTO> getShowTimingsByMerchantId(Integer merchantId) {
        List<ShowTiming> showTimings = showTimingRepository.findByMerchantId(merchantId);
        List<ShowTimingDTO> dtoList = new ArrayList<>();

        for (ShowTiming show : showTimings) {
            String movieName = movieRepository.findById(show.getMovieId())
                                .map(Movie::getTitle)
                                .orElse("Unknown Movie");

            String cinemaName = cinemaRepository.findById(show.getCinemaId())
                                .map(Cinema::getName)
                                .orElse("Unknown Cinema");


            ShowTimingDTO dto = new ShowTimingDTO(
                movieName,
                cinemaName,
                show.getShowDate(),
                show.getShowTime(),
                show.getTotalSeats(),
                show.getTicketPrice()
            );

            dtoList.add(dto);
        }
        System.out.println(dtoList);

        return dtoList;
    }

    
    public List<ShowTiming> getShowTimingsByCinemaId(Integer cinemaId) {
    	logger.debug("Retrieving All Show Timing By Cinema Id: {}", cinemaId);
        return showTimingRepository.findByCinemaId(cinemaId);
    }
    
    public List<ShowTiming> getShowTimingsByMovieIdAndCinemaId(Integer movieId, Integer cinemaId) {
        return showTimingRepository.findByMovieIdAndCinemaId(movieId, cinemaId);
    }
}