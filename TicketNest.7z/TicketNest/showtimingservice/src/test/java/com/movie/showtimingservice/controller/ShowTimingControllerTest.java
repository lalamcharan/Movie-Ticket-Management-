package com.movie.showtimingservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.movie.showtimingservice.entity.ShowTiming;
import com.movie.showtimingservice.service.ShowTimingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;

import java.util.List;

@ExtendWith(MockitoExtension.class)
class ShowTimingControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ShowTimingService showTimingService;

    @InjectMocks
    private ShowTimingController showTimingController;

    private ShowTiming showTiming;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(showTimingController).build();
        showTiming = new ShowTiming();
        showTiming.setId(1);
        showTiming.setAvailableSeats(100);
    }

    @Test
    void testAddShowTiming() throws Exception {
        when(showTimingService.addShowTiming(any(ShowTiming.class))).thenReturn(showTiming);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/show-timings")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(showTiming)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.availableSeats").value(100));
    }

    @Test
    void testUpdateShowTiming() throws Exception {
        when(showTimingService.updateShowTiming(anyInt(), any(ShowTiming.class))).thenReturn(showTiming);

        mockMvc.perform(MockMvcRequestBuilders.put("/api/show-timings/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(showTiming)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.availableSeats").value(100));
    }

    @Test
    void testDeleteShowTiming() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/show-timings/1"))
                .andExpect(MockMvcResultMatchers.status().isOk());
        verify(showTimingService, times(1)).deleteShowTiming(1);
    }

    @Test
    void testGetAllShowTimings() throws Exception {
        when(showTimingService.getAllShowTimings()).thenReturn(List.of(showTiming));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/show-timings"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].availableSeats").value(100));
    }

    @Test
    void testGetShowTimingById() throws Exception {
        when(showTimingService.getShowTimingById(1)).thenReturn(showTiming);

        mockMvc.perform(MockMvcRequestBuilders.get("/api/show-timings/1"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.availableSeats").value(100));
    }
}