package com.movie.showtimingservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.movie.showtimingservice.entity.ShowTiming;
import com.movie.showtimingservice.repository.ShowTimingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class ShowTimingServiceTest {

    @Mock
    private ShowTimingRepository showTimingRepository;

    @InjectMocks
    private ShowTimingService showTimingService;

    private ShowTiming showTiming;

    @BeforeEach
    void setUp() {
        showTiming = new ShowTiming();
        showTiming.setId(1);
        showTiming.setShowTime(LocalTime.now());
        showTiming.setAvailableSeats(100);
        showTiming.setTotalSeats(100);
    }

    @Test
    void testAddShowTiming() {
        when(showTimingRepository.save(any(ShowTiming.class))).thenReturn(showTiming);

        ShowTiming savedShowTiming = showTimingService.addShowTiming(showTiming);

        assertNotNull(savedShowTiming);
        assertEquals(100, savedShowTiming.getAvailableSeats());
    }

    @Test
    void testUpdateShowTiming() {
        ShowTiming updatedShowTiming = new ShowTiming();
        updatedShowTiming.setShowTime(LocalTime.now().plusHours(1));

        when(showTimingRepository.findById(1)).thenReturn(Optional.of(showTiming));
        when(showTimingRepository.save(any(ShowTiming.class))).thenReturn(updatedShowTiming);

        ShowTiming result = showTimingService.updateShowTiming(1, updatedShowTiming);

        assertNotNull(result);
    }

    @Test
    void testDeleteShowTiming() {
        when(showTimingRepository.findById(1)).thenReturn(Optional.of(showTiming));

        assertDoesNotThrow(() -> showTimingService.deleteShowTiming(1));
        verify(showTimingRepository, times(1)).delete(showTiming);
    }

    @Test
    void testGetShowTimingById() {
        when(showTimingRepository.findById(1)).thenReturn(Optional.of(showTiming));

        ShowTiming result = showTimingService.getShowTimingById(1);

        assertNotNull(result);
    }
}