package com.movie.ticketservice.controller;

import org.apache.hc.core5.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.movie.ticketservice.dto.TicketWithMovieDTO;
import com.movie.ticketservice.entity.Ticket;
import com.movie.ticketservice.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ticket")
public class TicketController {
    private static final Logger logger = LoggerFactory.getLogger(TicketController.class);

    @Autowired
    private TicketService ticketService;

    @PostMapping
    public ResponseEntity<Ticket> addTicket(@RequestBody Ticket ticket) {
        logger.info("Received request to book a ticket: User ID {}", ticket.getUserId());

        Ticket bookedTicket = ticketService.addTicket(ticket);
        logger.info("Ticket booked successfully with QR Code: {}", bookedTicket.getQrCode());

        return ResponseEntity.ok(bookedTicket);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Ticket> updateTicket(@PathVariable Integer id, @RequestBody Ticket ticket) {
        logger.info("Received request to update ticket ID: {}", id);
        return ResponseEntity.ok(ticketService.updateTicket(id, ticket));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTicket(@PathVariable Integer id) {
        logger.warn("Deleting ticket ID: {}", id);
        try {
            ticketService.deleteTicket(id);
            return ResponseEntity.ok("Ticket deleted successfully.");
        } catch (RuntimeException ex) {
            logger.error("Error deleting ticket: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.SC_NOT_FOUND).body(ex.getMessage());
        } catch (Exception ex) {
            logger.error("Unexpected error: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body("An unexpected error occurred.");
        }
    }


    @GetMapping
    public ResponseEntity<List<Ticket>> getAllShowTimings() {
        logger.debug("Fetching all tickets...");
        return ResponseEntity.ok(ticketService.getAllTickets());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Ticket> getShowTimingById(@PathVariable Integer id) {
        logger.debug("Fetching ticket with ID: {}", id);
        return ResponseEntity.ok(ticketService.getTicketById(id));
    }
    
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<TicketWithMovieDTO>> getTicketsByUserId(@PathVariable Integer userId) {
        logger.debug("Fetching ticket with User ID: {}", userId);
        return ResponseEntity.ok(ticketService.getTicketsByUserId(userId));
    }

    @GetMapping("/merchant/{merchantId}/tickets")
    public ResponseEntity<List<TicketWithMovieDTO>> getTicketsByMerchant(@PathVariable Long merchantId) {
        logger.debug("Fetching tickets for Merchant ID: {}", merchantId);
        List<TicketWithMovieDTO> tickets = ticketService.getTicketsByMerchantId(merchantId);
        return ResponseEntity.ok(tickets);
    }
}