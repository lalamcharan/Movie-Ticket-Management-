package com.movie.ticketservice.repository;

import java.util.Optional;
import com.movie.ticketservice.entity.Cinema;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface CinemaRepository extends JpaRepository<Cinema, Integer> {

	
	Optional<Cinema>  findById(Integer id);


}