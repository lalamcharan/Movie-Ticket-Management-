package com.movie.ticketservice.service;
import com.movie.ticketservice.entity.ShowTiming;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.movie.ticketservice.entity.Cinema;
import com.movie.ticketservice.entity.Movie;
import com.movie.ticketservice.entity.ShowTiming;
import com.movie.ticketservice.repository.ShowTimingRepository;
import com.movie.ticketservice.repository.MovieRepository;
import com.movie.ticketservice.repository.CinemaRepository;

import com.movie.ticketservice.dto.TicketWithMovieDTO;
import com.movie.ticketservice.entity.Ticket;
import com.movie.ticketservice.exceptions.TicketNotFoundException;
import com.movie.ticketservice.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class TicketService {
    private static final Logger logger = LoggerFactory.getLogger(TicketService.class);

    @Autowired
    private TicketRepository ticketRepository;
    
    @Autowired
    private ShowTimingRepository showTimingRepository;
    
    @Autowired
    private MovieRepository movieRepository;
    
    @Autowired
    private CinemaRepository cinemaRepository;

    public Ticket addTicket(Ticket ticket) {
        logger.info("Booking ticket for User ID: {}", ticket.getUserId());

        String randomQRCode = UUID.randomUUID().toString();
        ticket.setQrCode(randomQRCode);
        logger.info("Generated QR Code for ticket: {}", randomQRCode);

        ticket.setBookingTiming(LocalDateTime.now());
        Ticket savedTicket = ticketRepository.save(ticket);

        logger.info("Ticket booked successfully with ID: {}", savedTicket.getId());
        return savedTicket;
    }

    public Ticket updateTicket(Integer id, Ticket ticketDetails) {
        logger.info("Updating ticket ID: {}", id);
        Ticket ticket = ticketRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Ticket not found: ID {}", id);
                    return new RuntimeException("Ticket not found with id " + id);
                });

        ticket.setBookingTiming(ticketDetails.getBookingTiming());
        ticket.setQrCode(ticketDetails.getQrCode());
        ticket.setSeatsBooked(ticketDetails.getSeatsBooked());
        ticket.setShowId(ticketDetails.getShowId());
        ticket.setStatus(ticketDetails.getStatus());
        ticket.setUserId(ticketDetails.getUserId());

        Ticket updatedTicket = ticketRepository.save(ticket);
        logger.info("Ticket updated successfully: ID {}", updatedTicket.getId());

        return updatedTicket;
    }

    public void deleteTicket(Integer id) {
        logger.warn("Deleting ticket with ID: {}", id);
        Ticket ticket = ticketRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Ticket not found for deletion: ID {}", id);
                    return new RuntimeException("Ticket not found with id " + id);
                });

        ticketRepository.delete(ticket);
        logger.info("Ticket deleted successfully: ID {}", id);
    }


    public List<Ticket> getAllTickets() {
        logger.debug("Retrieving all booked tickets...");
        return ticketRepository.findAll();
    }

    public Ticket getTicketById(Integer id) {
        logger.debug("Retrieving ticket by ID: {}", id);
        return ticketRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Ticket not found: ID {}", id);
                    return new RuntimeException("Ticket not found with id " + id);
                });
    }
    
    public List<Ticket> getTicketByClientId(Integer userId) {
        logger.debug("Retrieving tickets for User ID: {}", userId);
        
        List<Ticket> tickets = ticketRepository.findByUserId(userId);
        
        if (tickets.isEmpty()) {
            logger.error("No tickets found for User ID: {}", userId);
            throw new TicketNotFoundException("No tickets found for User ID: " + userId);
        }

        return tickets;
    }
    
    public List<TicketWithMovieDTO> getTicketsByMerchantId(Long merchantId) {
    	logger.debug("Retrieving ticket by Merchant ID: {}", merchantId);
        List<Object[]> results = ticketRepository.findAllTicketsWithMovieNameByMerchantId(merchantId);
        return results.stream().map(obj -> new TicketWithMovieDTO(
            (Integer) obj[0],
            (Integer) obj[1],
            (String) obj[2],
            (Integer) obj[3],
            (String) obj[4],
            (Integer) obj[5],
            (String) obj[6],
            obj[7] != null ? ((java.sql.Timestamp) obj[7]).toLocalDateTime() : null,
            (String) obj[8]
        )).toList();
    }
    
    public List<TicketWithMovieDTO> getTicketsByUserId(Integer userId) {
        List<Ticket> tickets = ticketRepository.findByUserId(userId);
        List<TicketWithMovieDTO> dtoList = new ArrayList<>();

        for (Ticket ticket : tickets) {
            Optional<ShowTiming> showOpt = showTimingRepository.findById(ticket.getShowId());

            if (showOpt.isPresent()) {
                ShowTiming show = showOpt.get();

                String movieName = movieRepository.findById(show.getMovieId())
                                    .map(Movie::getTitle)
                                    .orElse("Unknown Movie");

                String cinemaName = cinemaRepository.findById(show.getCinemaId())
                                    .map(Cinema::getName)
                                    .orElse("Unknown Cinema");

                TicketWithMovieDTO dto = new TicketWithMovieDTO(
                    ticket.getId(),
                    ticket.getStatus(),
                    ticket.getSeatNumbers(),
                    ticket.getQrCode(),
                    ticket.getBookingTiming(),
                    movieName,
                    show.getShowDate(),
                    show.getShowTime()
                );

                dtoList.add(dto);
            }
        }

        System.out.println(dtoList);
        return dtoList;
    }

}