package com.movie.ticketservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
