package com.movie.ticketservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.movie.ticketservice.entity.Ticket;
import com.movie.ticketservice.service.TicketService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;

import java.util.List;

@ExtendWith(MockitoExtension.class)
class TicketControllerTest {

    private MockMvc mockMvc;

    @Mock
    private TicketService ticketService;

    @InjectMocks
    private TicketController ticketController;

    private Ticket ticket;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(ticketController).build();
        ticket = new Ticket();
        ticket.setId(1);
        ticket.setQrCode("TestQRCode");
    }

    @Test
    void testAddTicket() throws Exception {
        when(ticketService.addTicket(any(Ticket.class))).thenReturn(ticket);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/ticket")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(ticket)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.qrCode").value("TestQRCode"));
    }

    @Test
    void testUpdateTicket() throws Exception {
        when(ticketService.updateTicket(anyInt(), any(Ticket.class))).thenReturn(ticket);

        mockMvc.perform(MockMvcRequestBuilders.put("/api/ticket/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(ticket)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.qrCode").value("TestQRCode"));
    }

    @Test
    void testDeleteTicket() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/ticket/1"))
                .andExpect(MockMvcResultMatchers.status().isOk());
        verify(ticketService, times(1)).deleteTicket(1);
    }

    @Test
    void testGetAllTickets() throws Exception {
        when(ticketService.getAllTickets()).thenReturn(List.of(ticket));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/ticket"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].qrCode").value("TestQRCode"));
    }

    @Test
    void testGetTicketById() throws Exception {
        when(ticketService.getTicketById(1)).thenReturn(ticket);

        mockMvc.perform(MockMvcRequestBuilders.get("/api/ticket/1"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.qrCode").value("TestQRCode"));
    }
}