package com.movie.ticketservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.movie.ticketservice.entity.Ticket;
import com.movie.ticketservice.repository.TicketRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@ExtendWith(MockitoExtension.class)
class TicketServiceTest {

    @Mock
    private TicketRepository ticketRepository;

    @InjectMocks
    private TicketService ticketService;

    private Ticket ticket;

    @BeforeEach
    void setUp() {
        ticket = new Ticket();
        ticket.setId(1);
        ticket.setQrCode(UUID.randomUUID().toString());
        ticket.setBookingTiming(LocalDateTime.now());
    }

    @Test
    void testAddTicket() {
        when(ticketRepository.save(any(Ticket.class))).thenReturn(ticket);

        Ticket savedTicket = ticketService.addTicket(ticket);

        assertNotNull(savedTicket);
        assertEquals(ticket.getQrCode(), savedTicket.getQrCode());
    }

    @Test
    void testUpdateTicket() {
        Ticket updatedTicket = new Ticket();
        updatedTicket.setQrCode("UpdatedQRCode");

        when(ticketRepository.findById(1)).thenReturn(Optional.of(ticket));
        when(ticketRepository.save(any(Ticket.class))).thenReturn(updatedTicket);

        Ticket result = ticketService.updateTicket(1, updatedTicket);

        assertNotNull(result);
        assertEquals("UpdatedQRCode", result.getQrCode());
    }

    @Test
    void testDeleteTicket() {
        when(ticketRepository.findById(1)).thenReturn(Optional.of(ticket));

        assertDoesNotThrow(() -> ticketService.deleteTicket(1));
        verify(ticketRepository, times(1)).delete(ticket);
    }

    @Test
    void testGetTicketById() {
        when(ticketRepository.findById(1)).thenReturn(Optional.of(ticket));

        Ticket result = ticketService.getTicketById(1);

        assertNotNull(result);
        assertEquals(ticket.getQrCode(), result.getQrCode());
    }
}