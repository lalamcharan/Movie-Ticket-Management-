import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClientHeaderComponent } from 'src/app/components/client-header/client-header.component';

@Component({
  imports: [CommonModule, ClientHeaderComponent],
  selector: 'app-client-profile',
  templateUrl: './client-profile.component.html',
  styleUrls: ['./client-profile.component.scss']
})
export class ClientProfileComponent implements OnInit {
  user: any = {};

  constructor(private router: Router) {}

  ngOnInit(): void {
    const storedUser = sessionStorage.getItem('userData');
    if (storedUser) {
      this.user = JSON.parse(storedUser);
    }
  }

  editProfile() {
    console.log('Edit profile clicked');
  }

  goToBookings() {
    console.log('Navigating to bookings...');
    this.router.navigate(['/my-bookings']);
  }
}
